package intern;
import java.util.Scanner;

public class Task1 {
    public static double celsiusToFahrenheit(double celsius) {
        return (celsius * 9/5) + 32;
    }

    public static double celsiusToKelvin(double celsius) {
        return celsius + 273.15;
    }

    public static double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5/9;
    }

    public static double fahrenheitToKelvin(double fahrenheit) {
        return (fahrenheit - 32) * 5/9 + 273.15;
    }

    public static double kelvinToCelsius(double kelvin) {
        return kelvin - 273.15;
    }

    public static double kelvinToFahrenheit(double kelvin) {
        return (kelvin - 273.15) * 9/5 + 32;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Temperature Converter");
        System.out.println("1: Celsius to Fahrenheit/Kelvin");
        System.out.println("2: Fahrenheit to Celsius/Kelvin");
        System.out.println("3: Kelvin to Celsius/Fahrenheit");
        System.out.print("Enter your choice (1-3): ");
        
        int choice = scanner.nextInt();
        double inputTemp;

        switch (choice) {
            case 1:
                System.out.print("Enter temperature in Celsius: ");
                inputTemp = scanner.nextDouble();
                System.out.printf("Fahrenheit: %.2f\n", celsiusToFahrenheit(inputTemp));
                System.out.printf("Kelvin: %.2f\n", celsiusToKelvin(inputTemp));
                break;
            case 2:
                System.out.print("Enter temperature in Fahrenheit: ");
                inputTemp = scanner.nextDouble();
                System.out.printf("Celsius: %.2f\n", fahrenheitToCelsius(inputTemp));
                System.out.printf("Kelvin: %.2f\n", fahrenheitToKelvin(inputTemp));
                break;
            case 3:
                System.out.print("Enter temperature in Kelvin: ");
                inputTemp = scanner.nextDouble();
                System.out.printf("Celsius: %.2f\n", kelvinToCelsius(inputTemp));
                System.out.printf("Fahrenheit: %.2f\n", kelvinToFahrenheit(inputTemp));
                break;
            default:
                System.out.println("Invalid choice! Please select a valid option.");
        }

        scanner.close();
    }
}
